# Print & door drops

The A5 door-drop flyer is the reference print build. Its files are in the **Examples** asset group.

## Spec

| | |
|---|---|
| Trim | A5, 148 × 210 mm |
| Bleed | 3 mm each side (artboard 154 × 216 mm) |
| Safe area | 5 mm inside trim, so no text closer than 8 mm to the artboard edge |
| Colour | Supply as RGB and ask the printer to convert, or convert to CMYK yourself. Lime is outside CMYK and prints slightly duller. Ask for a proof. |
| Stock | 350–400 gsm silk for a card feel. 170 gsm gloss for high-volume door drops. |
| Minimum text | 7 pt for small print, 9 pt for anything someone needs to read |

## Front and back

- **Front (ink):** logo top-left, the two-line Anton headline, a lead line, a StepCard row, a CtaPanel with the WhatsApp number and QR code, and a TrustStrip at the foot. One Stamp at most. Lime slashes off the top-right and bottom-left corners.
- **Back (paper):** an ink band with an eyebrow and h1, a ServiceCard grid (3 × 2), a CoverageMap beside a *Why Offload?* checklist, the fly-tipping warning, and an ink contact band with the QR code repeated.

## QR codes

Point to `https://wa.me/447777365390` with a pre-filled message. Print at least 20 mm square with a white quiet zone, and test-scan the proof.
