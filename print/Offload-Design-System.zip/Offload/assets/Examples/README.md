# Examples

The A5 door-drop flyer, the reference build of this system: `a5-flyer-front.png`, `a5-flyer-back.png` and the print-ready `a5-flyer-print.pdf` (154 × 216 mm including 3 mm bleed, with the TrimBox set). The coverage radius and some service wording still need confirming. See the Print & door drops section.
