# Logos

- `offload-logo.png`: the master, on white (1254 px square).
- `offload-logo-transparent.png`: ink and lime on a transparent background, for light grounds.
- `offload-logo-reversed.png`: white and lime on a transparent background, for ink grounds.

The two PNGs were made from the master by recolouring its pixels (upscaled 2× from the 1254 px master and cropped). No vector master exists yet, so get one before van wraps, signage or anything larger than A3.
