# Icons

Seventeen line icons drawn for the Offload flyer on a 24 × 24 grid with a 2px round stroke. The files are drawn in ink (#111111). When you inline them, set the stroke to `currentColor` and colour them from tokens.

- Services: house, sofa, hard-hat, leaf, bin
- Process: camera, send, truck
- Trust: clock, licence, shield-check, check, alert
- Contact: whatsapp, phone, mail, globe

Place them inside a `radius-pill` disc: an `accent` disc with an `on-accent` icon on dark, or an `ink` disc with a `lime` icon on light. The TrustStrip uses bare lime icons. The WhatsApp glyph is a simplified outline, not WhatsApp's official logo. Use the official asset wherever WhatsApp's brand rules require it.
