# Offload

Licensed waste removal, Leeds. This is the brand book: check it before anything goes out with the Offload name on it, whether that's a door-drop flyer, a social tile, the van livery, a page of the site or an invoice.

## What Offload is

Offload is a local waste-removal operator with a short quote path. Every piece of communication does one of four things:

1. gets a photo of the waste sent over WhatsApp,
2. gets a call to the 0113 number,
3. proves the business is licensed, insured and local, or
4. ranks the website for waste-removal searches in Leeds.

The tone follows from that job. Offload sounds like a licensed local operator, not an ad agency: short, concrete and never dressed up.

## Business facts

Use these exact values. Don't retype them from memory.

| | |
|---|---|
| Phone | 0113 460 5439 |
| WhatsApp (photos) | 07777 365390 |
| Email | info@offloadwaste.com |
| Web | offloadwaste.com |
| Waste carrier licence | CBDU662023 |
| Insurance | £2M public liability |
| Services | House clearances · Furniture removal · Builders waste · Garden clearance · General waste |
| Sectors | Domestic · Commercial · Construction |

Same-day collection is only ever offered with the qualifier **when capacity allows**.

## Voice

**Do:**
- Write short sentences with plain verbs.
- Name the real thing (a sofa, a fridge, a garden clearance) instead of a category ("items", "solutions").
- Say what happens next: photo → price → we load it → it's disposed of legally.

**Don't:**
- Use "solutions", "passionate team", or any unmeasured green claim ("up to 100% recycled" without a real figure).
- Use fake urgency or invented discounts.
- Write "We proudly serve the [suburb] community and surrounding areas". Never open a page like this.

### Approved lines

Use these as written. Don't soften them.

- Got a load? Offload.
- Licensed waste removal in Leeds.
- Send photos and the postcode. We quote.
- Snap it. Send it. Sorted.
- If it's gotta go, we'll take it.
- One call. One van. Job done.
- We load it. You get a transfer note.
- Same-day when capacity allows.
- Alternative to a skip. No permit on the street.
- Know who takes your waste: if it's fly-tipped, you can be fined.

### Calls to action

Only three button labels are allowed: **Get a quote**, **Call now**, **WhatsApp photos**.

In print, the CTA is the WhatsApp number itself, set large in the `number` style inside a lime CtaPanel with a QR code. The office number sits under it as the secondary line.

## Logo

The master mark is a black open ring with a lime triangle exiting the lower-right gap. Below it, OFFLOAD is set in a heavy grotesque with a lime bar under OFFLOAD only, and a letterspaced WASTE REMOVAL line underneath. All logo files are in the **Logos** asset group:

- `offload-logo.png`: the master on white (1254 px square, supplied 29 Sep 2026).
- `offload-logo-transparent.png`: the same artwork with a transparent background, for light grounds that aren't pure white.
- `offload-logo-reversed.png`: a white ring and wordmark with the lime kept, for ink grounds.

The reversed and transparent files were made from the supplied master by recolouring its pixels, not redrawn. They are high-resolution but still raster. Ask the designer for a vector (SVG/PDF) master before large-format work such as van wraps or signage.

Never place the mark on a busy photo, never recolour the triangle, and never stretch the lockup. Keep clear space of at least the triangle's height around it.

## Colour

Offload is **ink and lime**. White and paper give relief, and graphite and ash are for secondary text only.

- **Ink** is the ground of every print and social piece and the text colour on white.
- **Lime** is the accent: the CTA panel and buttons, the bar under OFFLOAD, the second headline line on dark, and the diagonal slashes. Use one lime panel per piece at most. Everything else in lime is a line, a slash or a word.
- **Paper** is the ground of info-heavy sides (a flyer back), with white cards on it.
- Lime is never text on white or paper, because it fails contrast. Use the `text-accent` token, which swaps to ink on light.

Two themes: **Light** (website, paper backs) and **Dark** (flyer fronts, social, footers). Build with the role tokens (`surface`, `surface-alt`, `text`, `text-muted`, `text-accent`, `border`, `accent`, `on-accent`) and the piece works in either.

## Type

Three families, all free from Google Fonts. The font files are in this system.

- **Anton**: headlines, the hero shout, and phone numbers used as CTAs. Always uppercase and tight.
- **Barlow Condensed** (600/700/800): titles, eyebrows, labels and contact lines. Uppercase with a little tracking.
- **Barlow** (500/700): running copy and card descriptions. Sentence case.

Google Fonts link: `https://fonts.googleapis.com/css2?family=Anton&family=Barlow+Condensed:wght@600;700;800&family=Barlow:wght@500;700&display=swap`

Headline pattern: line one in `text`, line two in `text-accent`, both the same width if the piece allows it.

## Graphic devices

- **Diagonal slashes**: parallel bands at `slash-angle` bleeding off one or two corners. Lime is the loud one, and `ink-raised` is the quiet one behind it. No more than three slashes per face.
- **Icon discs**: line icons (Icons group) at a 2px stroke inside a pill disc. Use a lime disc with an ink icon on dark, and an ink disc with a lime icon on light.
- **Stamp**: one rotated round badge per piece for the single strongest offer (e.g. *Same day collections\**).
- **Faint stripes**: optional 45° ink-raised stripes on large ink grounds, at low contrast.

## Layout

- Web: white ground, ink type, lime for the CTA, the bar and the mark. Header order: mark, nav, **Get a quote**, phone number.
- Print and social: ink ground, slashes off a corner, headline top-left, CTA panel in the lower third, trust strip at the foot.
- Put trust facts (licence number, insurance, same-day qualifier) in plain words, never as fake seals.
- Every piece ends with a way to contact us: the CtaPanel on a front, the contact band on a back or footer.

## Legal footer

This is required on every web page and formal document: company name and number, registered office, waste carrier number (CBDU662023), phone, email and a privacy link. The company name, number and registered office still need confirming, so don't publish a page without them.

## Components

- **Logomark**: the master on light and the reversed version on ink.
- **Button**: the three approved CTA labels.
- **CtaPanel**: the lime WhatsApp panel with the big number and QR code.
- **StepCard**: the three-step *Snap it / Send it / Sorted* process.
- **ServiceCard**: the five services plus the *Not on the list?* card.
- **TrustStrip**: same-day, licence and insurance in a row.
- **Stamp**: the rotated offer badge.
- **CoverageMap**: Leeds with 10- and 20-mile rings. The radius is still to be confirmed.

The **Examples** asset group holds the A5 door-drop flyer (front, back and the print PDF) as the reference build of this system.
