The lime call-to-action panel: WhatsApp kicker, the number in Anton, the office line and a QR code.

## Anatomy
1. Kicker: WhatsApp icon plus *WhatsApp us a photo for a free quote* in Barlow Condensed 800.
2. Number: `07777 365390` in the `number` style.
3. Secondary line: *Or call the office: 0113 460 5439*.
4. QR code (optional): white `radius-sm` box, at least 20 mm in print, with a two-line caption *Scan to WhatsApp us*.

## Usage
- One per piece, in the lower third of a front or at the end of a page. It's the only large lime fill allowed.
- It sits on ink or paper, never on a photo.
- The `accent` fill, `on-accent` text and `radius-lg` stay the same in both themes.
- Drop the QR code on screen, where the number becomes a WhatsApp link.
