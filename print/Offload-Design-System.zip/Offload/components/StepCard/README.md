The three-step quote process shown as a row of cards: Snap it, Send it, Sorted.

## Usage
- Always three cards in this order. The copy is fixed:
  1. **Snap it**: take a photo of whatever needs to go.
  2. **Send it**: WhatsApp it to us for a quick, clear quote.
  3. **Sorted**: we load it, take it away and dispose of it legally.
- Icons: camera, send, truck, in a `radius-pill` disc (`accent` fill, `on-accent` icon).
- The step number sits ghosted in the top-right corner (Anton, `border` colour). The order really is a sequence, which is why the numbers are there.
- Card: `surface-alt` fill, 1px `border` outline, `radius-md`, `space-16` padding. Title in the `title` style, coloured `text-accent`.
