The Offload mark as one fixed lockup: open ring, lime triangle, OFFLOAD with the lime bar, and WASTE REMOVAL.

## Files (Logos asset group)
- `offload-logo.png`: the master, on white.
- `offload-logo-transparent.png`: ink and lime on a transparent background, for paper or light tints.
- `offload-logo-reversed.png`: white and lime, for ink and other dark grounds.

## Usage
- On `white` or `paper`, use the master or the transparent file. On `ink`, use the reversed file.
- Never on lime. On a lime panel, drop the logo and let the panel carry the CTA.
- Minimum width: 25 mm in print, 96 px on screen.
- Clear space: at least the triangle's height on every side.
- Don't separate the ring from the wordmark, recolour the triangle, stretch the lockup, or put it over a busy photo.
- Both PNGs were made from the supplied master by recolouring pixels. Get a vector master before large-format work.
