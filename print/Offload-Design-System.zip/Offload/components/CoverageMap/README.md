A stylised map of the service area: Leeds at the centre, a solid 10-mile ring and a 20-mile core-area ring, with the surrounding towns and motorways.

## Usage
- **The 20-mile radius and the town list are assumptions** made for the first flyer. Confirm them with the business before reuse.
- A stylised diagram, not a street map. It's plotted from real latitude and longitude, with miles as the unit.
- Rings use `lime` at reduced opacity with `lime-deep` strokes. Towns are ink dots with Barlow Condensed labels. Leeds gets the ink disc with a lime centre and an ink label chip.
- Always put a line under it: *Based in Leeds, covering West Yorkshire & beyond. Outside the area? Message us – we'll always try.*
- Place it on white inside a card with `radius-md`. Never on ink.
