A round, slightly rotated badge for the single strongest offer on a piece.

## Usage
- One per piece, or none. It sits beside the headline and never covers words.
- `accent` disc with `on-accent` text, rotated 12°. A ring of the ground colour plus a thin lime outer ring lets it read on ink.
- Two lines of Anton plus one Barlow Condensed line. Current copy: **Same day / collections\***. The asterisk must be answered by *\*When capacity allows* elsewhere on the piece.
- Don't use it for discounts or prices that aren't real.
