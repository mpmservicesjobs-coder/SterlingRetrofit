One service as a card: icon disc, title and a line of real examples.

## The set
| Icon | Title | Description |
|---|---|---|
| house | House clearances | Full or part clearances: lofts, garages, sheds, end-of-tenancy and probate. |
| sofa | Furniture removal | Sofas, beds, mattresses, wardrobes, white goods and more. |
| hard-hat | Builders waste | Rubble, timber, packaging and strip-out waste from homes and sites. |
| leaf | Garden clearance | Green waste, cuttings, old sheds, fencing and garden junk. |
| bin | General waste | Bags, boxes, clutter and one-off loads, big or small. |

The sixth cell in a 3 × 2 grid is the **ask** variant: a lime card with *Not on the list?* in Anton and *Send us a photo. If we can legally take it, we will.*

## Usage
- Card: `white` on `paper` (light) with a `rule` hairline and `radius-md`. Icon disc: `ink` with a lime icon.
- Name real items. Never write "all types of waste" or "and much more".
- Only one ask card per grid.
