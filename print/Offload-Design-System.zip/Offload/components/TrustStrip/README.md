Three proof points in a row at the foot of a piece: same-day service, licence number and insurance.

## Content (fixed)
| Icon | Heading | Sub-line |
|---|---|---|
| clock | Same-day service | *When capacity allows |
| licence | Licensed waste carrier | CBDU662023 |
| shield-check | £2M public liability | Fully insured |

## Usage
- Lime line icons with no disc. Headings in the `title` style at 16–18 px, sub-lines in the `label` style in `text-muted`.
- Columns are split by 1px `border` rules, with a rule across the top.
- The same-day claim always keeps its qualifier.
- Plain words, never seal or badge graphics.
