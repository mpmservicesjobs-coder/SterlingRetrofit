The three approved CTA buttons, always lime with ink type.

## Usage
- Labels are fixed: **Get a quote**, **Call now**, **WhatsApp photos**. Don't write new button copy.
- Primary: `accent` fill, `on-accent` text, `radius-md`, Barlow Condensed 800 uppercase with a leading icon (whatsapp, phone or camera from the Icons group).
- Ghost: transparent with a 1.5px `border` outline and `text` colour. Use it only beside a primary button, never as the only CTA.
- On ink, the primary is unchanged. The ghost outline switches to `ink-line`, and the text to white.
